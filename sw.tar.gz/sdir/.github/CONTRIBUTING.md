Thank you for contributing to continuable!
=========================================

## Notifications

Usually I try to respond to issues and pull requests as fast as possible. In case you are waiting longer for my response, you may notify me through mail: `denis.blank <at> outlook <dot> com`.

## Templates

Please use the issue/PR templates which are inserted automatically.


../../../amalgamate/amalgamate.py --config=amalgamate.json  --prologue=amalgamate.hpp.prologue --source=../..
